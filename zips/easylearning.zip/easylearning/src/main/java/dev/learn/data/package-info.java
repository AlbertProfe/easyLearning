@NonNullApi
package dev.learn.data;

import org.springframework.lang.NonNullApi;
