package dev.learn.data;

public enum Role {
    USER, ADMIN;
}
